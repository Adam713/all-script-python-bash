# Computer-Details
Get hardware and software details for your computer
