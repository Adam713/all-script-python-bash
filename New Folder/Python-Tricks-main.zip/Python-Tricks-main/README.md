# Python-Tricks
Diffferent tips and tricks for clean and effective python programming
