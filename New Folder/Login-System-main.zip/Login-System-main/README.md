# Login-System
Simple Login system with encryption

- Login  
  - Simple login with hidden passphrase.  
  - Verifies login from users.txt  
- Sign Up  
  - Simple sign up with hidden passphrase.  
  - Checks for duplicate username under registration.  
  - Saves data to users.txt  
- User Encryption  
  - Decrypts users.txt in start of script.  
  - Encrypts users.txt in the end of the script.  
